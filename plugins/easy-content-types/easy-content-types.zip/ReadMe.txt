================ INSTALLATION ================

To install Easy Content Types, simply upload the unzipped folder called "easy-content-types" to yout wp-content/plugins directory.

Next, navigate to your WordPress plugins menu anc click "Activate" on "Easy Content Types".

You will now have a new menu item called "Content Types". This is where you will create new post types, taxonomes, and metaboxes.

================ USAGE =======================

For your convienance, all usage documentation has been included inside WordPress.

Click on the "Help" link inside the "Content Types" menu.

================ SUPPORT =====================

For techinical support, please email me via my profile page on Code Canyon.net: http://codecanyon.net/user/mordauk
