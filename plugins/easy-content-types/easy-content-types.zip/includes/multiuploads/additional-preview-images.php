<?php

function leepro_additional_preview_images($field){             
	global $adpdir, $dir_view_file;
	$images = (get_post_meta($_GET['post'],$field['id'],true));
	//var_dump($images);
    //@extract(get_post_meta($_GET['post'],$field['id'],true)); 
    //wp_enqueue_script('swfobject',plugins_url().'/easy-content-types/includes/multiuploads/js/swfobject.js');
    //wp_enqueue_script('uploadify',plugins_url().'/easy-content-types/includes/multiuploads/js/myplupload.js');
?>

<style type="">

#apvUploader {background: transparent url('<?php echo plugins_url(); ?>/easy-content-types/includes/multiuploads/images/browse.png') left top no-repeat; }

#apvUploader:hover {background-position: left bottom; }

.highlight{

    border:1px solid #F79D2B;

    background:#FDE8CE;

    width: 40px;

    height: 40px;

    float:left;padding:5px;

}

.adp{

    float:left;padding:5px;

}

</style>

<?php

// adjust values here

$id = $field['id'];// "img1"; // this will be the name of form field. Image url(s) will be submitted in $_POST using this key. So if $id == �img1� then $_POST[�img1�] will have all the image urls

 

$svalue = ""; // this will be initial value of the above form field. Image urls.

 

$multiple = true; // allow multiple files upload

 

$width = null; // If you want to automatically resize all uploaded images then provide width here (in pixels)

 

$height = null; // If you want to automatically resize all uploaded images then provide height here (in pixels)

?>

 

<label>Upload Images</label>

<input type="hidden" name="<?php echo $field['id']; ?>[<?php echo $field['id']; ?>]" id="<?php echo $id; ?>" value="<?php echo $svalue; ?>" />

<!--<input type="hidden" name="wpmp_list[images][]" id="<?php echo $id; ?>" value="<?php echo $svalue; ?>" />-->

<div class="plupload-upload-uic hide-if-no-js <?php if ($multiple): ?>plupload-upload-uic-multiple<?php endif; ?>" id="<?php echo $id; ?>plupload-upload-ui">

    <input id="<?php echo $id; ?>plupload-browse-button" type="button" value="<?php esc_attr_e('Select Files'); ?>" class="button" />

    <span class="ajaxnonceplu" id="ajaxnonceplu<?php echo wp_create_nonce($id . 'pluploadan'); ?>"></span>

    <?php if ($width && $height): ?>

            <span class="plupload-resize"></span><span class="plupload-width" id="plupload-width<?php echo $width; ?>"></span>

            <span class="plupload-height" id="plupload-height<?php echo $height; ?>"></span>

    <?php endif; ?>

    <div class="filelist"></div>

</div>

<div class="plupload-thumbs <?php if ($multiple): ?>plupload-thumbs-multiple<?php endif; ?>" id="<?php echo $id; ?>plupload-thumbs">

</div>

<div class="clear"></div>

<ul id="adpcon_<?php echo $field['id']; ?>">

<?php


    if(isset($images[$field['id']]) && is_array($images[$field['id']])){

        foreach($images[$field['id']] as $mpv){

            //if(file_exists($adpdir.$mpv)){

            ?>

             <li id='li_<?php echo $field['id']; ?>_<?php echo ++$mmv; ?>' class='adp'>

             <input type='hidden'  id='in_<?php echo $mmv; ?>' name='<?php echo $field['id']; ?>[<?php echo $field['id']; ?>][]' value='<?php echo $mpv; ?>' />

             <img style='position:absolute;z-index:9;cursor:pointer;' id='del_<?php echo $field['id'].$mmv; ?>' rel="li_<?php echo $field['id'].'_'.$mmv; ?>" src='<?php echo plugins_url(); ?>/easy-content-types/includes/multiuploads/images/remove.png' class="del_adp" align=left />

             <img src='<?php echo plugins_url(); ?>/easy-content-types/includes/multiuploads/libs/timthumb.php?w=50&h=50&zc=1&src=<?php echo $dir_view_file."/".$mpv; ?>'/>
			<br/>
			<?php 
			echo substr ( $mpv , 17 ) ?>
             <div style='clear:both'></div>

             </li>

            <?php

        }

    //}

    }

?>

</ul><br clear="all" />

<!--<input type="file" id="apv" name="apv">-->



<div class="clear"></div>
	<script type="text/javascript">
		jQuery(document).ready(function() {
			jQuery('#adpcon_<?php echo $field['id']; ?>').sortable({placeholder:'highlight'});
		});
	</script>
<?php    

} 



function leepro_format_name($text){

            $allowed = "/[^a-z0-9\\.\\-\\_]/i";      

            $text = preg_replace($allowed,"-",$text);

            $text = preg_replace("/([\\-]+)/i","-",$text);

            return $text;

}   



function leepro_upload_previews(){
	global $adpdir;
    // $adpdir = WP_PLUGIN_DIR.'/easy-content-types/includes/multiuploads/previews/';     

     if(isset($_FILES['Filedata']['tmp_name']) && is_uploaded_file($_FILES['Filedata']['tmp_name'])&&$_GET['task']=='leepro_upload_previews'){

        $tempFile = $_FILES['Filedata']['tmp_name'];    

        $targetFile =  $adpdir ."wpdm-adp-". time().'-'.leepro_format_name($_FILES['Filedata']['name']);

        move_uploaded_file($tempFile, $targetFile);

        echo basename($targetFile);        

        die();

     }

     

}



function leepro_delete_preview(){
	global $adpdir;
	
    //@unlink($adpdir.$_POST['file']);
	var_dump($adpdir.$_POST['file']);

    die();

}



 

 

function leepro_get_thumbs($id){
global $dir_view_file, $post;
	
    @extract(get_post_meta($id,"multiupload",true));      

    $img = '';     

     

    if($images){

    $t = count($images);

    foreach($images as $p){

        ++$k;

        echo "<a class='colorbox' rel='colorbox' title='{$post->post_title} &#187; Image {$k} of $t' href='".$dir_view_file."/{$p}' id='more_previews_a_{$k}' class='more_previews_a' ><img id='more_previews_{$k}' class='more_previews' src='".plugins_url().'/easy-content-types/includes/multiuploads/libs/timthumb.php?w='.get_option('_wpmp_athumb_w',80).'&h='.get_option('_wpmp_athumb_h',60).'&zc=1&src='.$dir_view_file.'/'.$p."'/></a>";

    }}

    

   

}



function leepro_meta_box_images($meta_boxes){

    $meta_boxes['wpmp-images'] = array('title'=>'Images','callback'=>'leepro_additional_preview_images','position'=>'side','priority'=>'low');

    return $meta_boxes;

}



if(is_admin())  {



    wp_enqueue_style('uploadify',plugins_url().'/easy-content-types/includes/multiuploads/css/myplupload.css');

    

    add_action("init","leepro_upload_previews");

    add_action("wp_ajax_leepro_delete_preview","leepro_delete_preview");

    add_filter("wpmp_meta_box","leepro_meta_box_images");
	
	//call 
	add_action( 'wp_ajax_moveuploadprevfile', 'leepro_move_upload_previewfile');
	add_action( 'wp_ajax_moveuploadprofile', 'leepro_move_upload_productfile');
	add_action( 'wp_ajax_moveuploadfeaturedfile', 'leepro_move_upload_featuredfile');
}




function leepro_plupload_admin_head() {
global $adpdir;
// place js config array for plupload
    $plupload_init = array(
        'runtimes' => 'html5,silverlight,flash,html4',
        'browse_button' => 'plupload-browse-button', // will be adjusted per uploader
        'container' => 'plupload-upload-ui', // will be adjusted per uploader
        'drop_element' => 'drag-drop-area', // will be adjusted per uploader
        'file_data_name' => 'async-upload', // will be adjusted per uploader
        'multiple_queues' => true,
        'max_file_size' => wp_max_upload_size() . 'b',
        'url' => admin_url('admin-ajax.php'),
        'flash_swf_url' => includes_url('js/plupload/plupload.flash.swf'),
        'silverlight_xap_url' => includes_url('js/plupload/plupload.silverlight.xap'),
        'filters' => array(array('title' => __('Allowed Files'), 'extensions' => '*')),
        'multipart' => true,
        'urlstream_upload' => true,
        'multi_selection' => false, // will be added per uploader
         // additional post data to send to our ajax hook
        'multipart_params' => array(
            '_ajax_nonce' => "", // will be added per uploader
            'action' => 'plupload_action', // the ajax action name
            'imgid' => 0 // will be added per uploader
        )
    );
?>
<script type="text/javascript">
    var base_plupload_config=<?php echo json_encode($plupload_init); ?>;
    var pluginurl = "<?php echo plugins_url("easy-content-types/includes/multiuploads/"); ?>";
	var pluginurltinymce = "<?php echo plugins_url("easy-content-types/includes/tinymce/"); ?>";
	var dir_file = "<?php echo get_bloginfo('home');?>/wp-content/uploads/";
</script>
<?php
}
add_action("admin_head", "leepro_plupload_admin_head");


function leepro_plupload_action() {
 
    // check ajax noonce
    $imgid = $_POST["imgid"];
    check_ajax_referer($imgid . 'pluploadan');
 
    // handle file upload
    $status = wp_handle_upload($_FILES[$imgid . 'async-upload'], array('test_form' => true, 'action' => 'plupload_action'));
 
    // send the uploaded file url in response
    echo $status['url'];
    exit;
}
add_action('wp_ajax_plupload_action', "leepro_plupload_action");

function leepro_move_upload_previewfile(){
	global $meta_name, $adpdir;
    $uploads = wp_upload_dir();
    $tempFile=$uploads['basedir'].str_replace("uploads","",strstr($_POST['fileurl'],"uploads"));
    $filename=basename($_POST['fileurl']);
    $fname= $meta_name.'-'. time().'-'.$filename;
    $targetFile =  $adpdir.$fname;
    rename($tempFile, $targetFile);
    die($fname);
}

function leepro_move_upload_productfile(){
	global $meta_name , $adpdir;
   
    $uploads = wp_upload_dir();
    $tempFile=$uploads['basedir'].str_replace("uploads","",strstr($_POST['fileurl'],"uploads"));
    $filename=basename($_POST['fileurl']);
    $fname=$meta_name.'-'. time().'-'.$filename;
    $targetFile =  $adpdir.$fname;
    rename($tempFile, $targetFile);
    die($fname);
}

function leepro_move_upload_featuredfile(){
    
    die($_POST['fileurl']);
}

 function leepro_plu_admin_enqueue() {
    /*if(!($condition_to_check_your_page))// adjust this if-condition according to your theme/plugin
       return;*/
    wp_enqueue_script('plupload-all');
 
    /*wp_register_script('myplupload', '/js/admin/myplupload.js', array('jquery'));
    wp_enqueue_script('myplupload');
 
    wp_register_style('myplupload', '/css/admin/myplupload.css');
    wp_enqueue_style('myplupload');*/
}
add_action( 'admin_enqueue_scripts', 'leepro_plu_admin_enqueue' );

function leepro_get_meta_mutiupload() {



    global $wpdb, $post;

	global $ecpt_prefix;

    global $ecpt_db_meta_name;

    global $ecpt_db_meta_fields_name;

	global $type_meta;
	$fields_array = array();
	$i = 0;
	foreach( $wpdb->get_results("SELECT * FROM  " . $ecpt_db_meta_name . " where page= '".$post->post_type."';") as $key => $metabox) 
	{
		foreach($wpdb->get_results("SELECT * FROM " . $ecpt_db_meta_fields_name . " WHERE parent = '" . $metabox->name ."' ORDER BY list_order;") as $key => $meta_field) 

		{

			if($meta_field->type == 'multiupload'){
				$fields_array[$i] = $meta_field;
				$i++;
			}

		}
	}	
	return $fields_array;
}

add_action( 'save_post', 'leepro_save_meta_data');

function leepro_save_meta_data(){     
		global $post;
		$args_multiupload = (leepro_get_meta_mutiupload());
		if($args_multiupload){
            foreach($args_multiupload as $key=>$value){
				 if($_POST[$value->name] && $_POST[$value->name]!= null){
				 update_post_meta($postid,$value->name,$_POST[$value->name]);  
				 foreach($_POST[$value->name] as $k=>$v){
						update_post_meta($postid,$k,$v);
					 }
				 }
			 }
		 }
         //print_r($_POST);
         if($_POST['original_post_status']=="draft" && $_POST['post_status']=="publish"){
             global $current_user;
             
             $userinfo=get_userdata($_POST['post_author']);
            $to= $userinfo->user_email; //post author
            $from= $current_user->user_email;
            $subject= get_bloginfo('name');
            $message  = get_bloginfo('admin_email');
            
            $healthy = array("[product_title]", "[product_description]","[username]","[product_url]");
            $yummy   = array($_POST['post_title'], $_POST['post_content'], $userinfo->first_name. " ". $userinfo->last_name,get_permalink( $_POST['post_ID'] ));
            echo $message = str_replace($healthy, $yummy, $message);
            //exit;
            //$message=str_replace()."\r\n" ;
            //$message="The Product you added has been approved. \r\n Product Info : \r\n Title: ".$_POST['post_title']." \r\n Description : ".$_POST['post_content']."\r\n" ;
            $headers = 'From:  <'.$from.'>' . "\r\n";
            wp_mail($to, $subject, $message, $headers );
         }
}
